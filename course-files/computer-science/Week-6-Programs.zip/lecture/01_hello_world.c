#include <stdio.h> // printf: print text and values.

void print_hello_world(void);

int main(void)
{
    print_hello_world();
    print_hello_world();
    return 0;
}

void print_hello_world(void)
{
    printf("Hello, world!\n");
}
