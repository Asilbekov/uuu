#include <stdio.h> // printf, puts: print text and values.

void print_meow(void);
void print_meows(int count);

int main(void)
{
    puts("count=1");
    print_meows(1);
    puts("count=3");
    print_meows(3);
    return 0;
}

void print_meow(void)
{
    printf("meow\n");
}

// Nonpositive counts print nothing. Reuse print_meow for each repetition.
void print_meows(int count)
{
    for (int i = 0; i < count; i++)
    {
        print_meow();
    }
}
