#include <stdio.h> // printf: print text and values.

typedef struct
{
    int water_ml;
    int milk_ml;
    int beans_g;
    int paper_cups;
} Stock;

Stock stock_after_water_use(Stock stock, int amount_ml);

int main(void)
{
    Stock stock = {500, 200, 40, 3};
    Stock preview = stock_after_water_use(stock, 100);
    printf("Original: %d ml\n", stock.water_ml);
    printf("Preview: %d ml\n", preview.water_ml);
    stock = stock_after_water_use(stock, 50);
    printf("After assignment: %d ml\n", stock.water_ml);
    return 0;
}

// Nonnegative stock; invalid amounts leave the returned copy unchanged.
Stock stock_after_water_use(Stock stock, int amount_ml)
{
    if (amount_ml >= 0 && amount_ml <= stock.water_ml)
    {
        stock.water_ml -= amount_ml;
    }
    return stock;
}
