// Classroom recipes, not a physical coffee-machine model.
// Use the supplied recipes and nonnegative stock. Foam is part of the latte milk.
#include <cs50.h> // get_int: read an integer from the user.
#include <limits.h> // INT_MAX: detect when get_int input ends.
#include <stdbool.h> // bool, true, false: yes/no values.
#include <stdio.h> // printf, puts: print text and values.

typedef struct
{
    int water_ml;
    int milk_ml;
    int beans_g;
    int paper_cups;
} Stock;

typedef struct
{
    int drink_id;
    int water_ml;
    int milk_ml;
    int beans_g;
    int paper_cups;
} Recipe;

typedef struct
{
    int drink_id;
    int coffee_ml;
    int milk_ml;
    int beans_used_g;
    int paper_cups_used;
    int frothed_milk_ml;
} Cup;

#define ESPRESSO 1
#define LATTE 2

static const Recipe MENU[2] = {{ESPRESSO, 100, 0, 10, 1}, {LATTE, 100, 50, 10, 1}};

void print_menu(void);
void print_stock(Stock stock);
void print_cup(Cup cup);
int read_choice(int maximum);
bool can_make_coffee(Stock stock, Recipe recipe);
Stock stock_after_coffee(Stock stock, Recipe recipe);
Cup create_cup(Recipe recipe, bool add_foam);

int main(void)
{
    Stock stock = {500, 200, 40, 3};
    Cup cup = {0};
    puts("Coffee machine: one drink per order.");
    print_stock(stock);
    print_cup(cup);
    while (true)
    {
        print_menu();
        int choice = read_choice(2);
        if (choice <= 0)
        {
            puts(choice == 0 ? "Goodbye." : "Input ended.");
            break;
        }
        Recipe recipe = MENU[choice - 1];
        bool add_foam = false;
        if (choice == LATTE)
        {
            puts("Foam: 0 = no, 1 = yes (uses 20 ml of the latte's 50 ml milk).");
            int foam_choice = read_choice(1);
            if (foam_choice < 0)
            {
                puts("Input ended. Order cancelled.");
                break;
            }
            add_foam = foam_choice == 1;
        }
        if (can_make_coffee(stock, recipe))
        {
            stock = stock_after_coffee(stock, recipe);
            cup = create_cup(recipe, add_foam);
            puts("Coffee ready.");
        }
        else
        {
            puts("Not enough ingredients or paper cups. No coffee made.");
        }
        print_stock(stock);
        print_cup(cup);
    }
    puts("Final state:");
    print_stock(stock);
    print_cup(cup);
    return 0;
}

bool can_make_coffee(Stock stock, Recipe recipe)
{
    return stock.water_ml >= recipe.water_ml &&
           stock.milk_ml >= recipe.milk_ml &&
           stock.beans_g >= recipe.beans_g &&
           stock.paper_cups >= recipe.paper_cups;
}

// The helper changes its copy. The caller chooses whether to keep the result.
Stock stock_after_coffee(Stock stock, Recipe recipe)
{
    if (can_make_coffee(stock, recipe))
    {
        stock.water_ml -= recipe.water_ml;
        stock.milk_ml -= recipe.milk_ml;
        stock.beans_g -= recipe.beans_g;
        stock.paper_cups -= recipe.paper_cups;
    }
    return stock;
}

Cup create_cup(Recipe recipe, bool add_foam)
{
    Cup cup = {recipe.drink_id, recipe.water_ml, recipe.milk_ml,
               recipe.beans_g, recipe.paper_cups, 0};
    if (add_foam && recipe.drink_id == LATTE)
    {
        cup.frothed_milk_ml = 20; // Part of the existing 50 ml, not extra milk.
    }
    return cup;
}

void print_menu(void)
{
    puts("1. Espresso");
    puts("2. Latte");
    puts("0. Quit");
}

void print_stock(Stock stock)
{
    printf("Stock: water=%d ml, milk=%d ml, beans=%d g, cups=%d\n",
           stock.water_ml, stock.milk_ml, stock.beans_g, stock.paper_cups);
}

void print_cup(Cup cup)
{
    if (cup.drink_id == 0)
    {
        puts("Last successful cup: none yet.");
        return;
    }
    printf("Last successful cup: %s, coffee=%d ml, milk=%d ml, beans used=%d g, cups used=%d, frothed milk=%d ml\n",
           cup.drink_id == ESPRESSO ? "Espresso" : "Latte", cup.coffee_ml, cup.milk_ml,
           cup.beans_used_g, cup.paper_cups_used, cup.frothed_milk_ml);
}

// CS50 handles integer parsing; this helper handles our allowed range and EOF.
int read_choice(int maximum)
{
    int choice;
    do
    {
        choice = get_int("Choose 0-%i: ", maximum);
        if (choice == INT_MAX)
        {
            return -1;
        }
    }
    while (choice < 0 || choice > maximum);
    return choice;
}
