#include <stdio.h> // printf: print text and values.

typedef struct
{
    int water_ml;
    int milk_ml;
    int beans_g;
    int paper_cups;
} Stock;

int main(void)
{
    Stock stock = {500, 200, 40, 3};
    printf("%d\n", stock.water_ml);
    stock.water_ml = 450;
    printf("%d\n", stock.water_ml);
    return 0;
}
