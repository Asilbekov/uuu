// Book section 7.2.1 (p.154) and Exercise 7.1.
// Modern adaptation: division avoids overflow in the book's cont * cont.
#include <limits.h> // INT_MAX: test the largest int value.
#include <stdio.h> // printf: print text and values.

int IntegerRoot(int number);

int main(void)
{
    int examples[] = {-1, 0, 1, 15, 16, 17, 27, INT_MAX};
    for (size_t i = 0; i < sizeof examples / sizeof examples[0]; i++)
    {
        printf("root(%d) = %d\n", examples[i], IntegerRoot(examples[i]));
    }

    int z = IntegerRoot(27);
    printf("Exercise 7.1(a): z = %d\n", z);
    z = 5;
    int x = z * z;
    z = IntegerRoot(x);
    printf("Exercise 7.1(b): x = %d, z = %d\n", x, z);
    int y = 10;
    int w = 4;
    z = 14 + IntegerRoot(y - w);
    printf("Exercise 7.1(c): z = %d\n", z);
    return 0;
}

int IntegerRoot(int number)
{
    if (number < 0)
    {
        return -1;
    }
    int root = 0;
    // For positive next, next <= number / next means next*next <= number.
    while (root + 1 <= number / (root + 1))
    {
        root++;
    }
    return root;
}
